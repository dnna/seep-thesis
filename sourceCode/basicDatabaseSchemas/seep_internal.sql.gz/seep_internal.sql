-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2011 at 04:03 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `seep_internal`
--

-- --------------------------------------------------------

--
-- Table structure for table `concurrencylock`
--

CREATE TABLE IF NOT EXISTS `concurrencylock` (
  `lockTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lotID` int(6) NOT NULL,
  `last_lock_hostname` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `last_lock_ip` varchar(16) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `concurrencylock`
--


-- --------------------------------------------------------

--
-- Table structure for table `curstudentlab`
--

CREATE TABLE IF NOT EXISTS `curstudentlab` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `labID` varchar(19) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `curstudentlab`
--


-- --------------------------------------------------------

--
-- Table structure for table `failedstudentcourse`
--

CREATE TABLE IF NOT EXISTS `failedstudentcourse` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `courseID` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `failReason` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `failedstudentcourse`
--


-- --------------------------------------------------------

--
-- Table structure for table `failedstudentlab`
--

CREATE TABLE IF NOT EXISTS `failedstudentlab` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `labID` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `failReason` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `failedstudentlab`
--


-- --------------------------------------------------------

--
-- Table structure for table `lotteries`
--

CREATE TABLE IF NOT EXISTS `lotteries` (
  `lotID` int(6) NOT NULL AUTO_INCREMENT,
  `lotDate` datetime NOT NULL,
  `lotExecuted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lotID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lotteries`
--


-- --------------------------------------------------------

--
-- Table structure for table `registrationpriorities`
--

CREATE TABLE IF NOT EXISTS `registrationpriorities` (
  `rpId` int(2) NOT NULL AUTO_INCREMENT,
  `rpPrio` int(2) NOT NULL,
  `rpName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rpDatasource` int(2) NOT NULL COMMENT '1 - SQL query στη βάση archonInternal',
  `rpParameters` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Οι παράμετροι που θα σταλούν στο datasource (πχ. το query)',
  `rpEnabled` int(1) NOT NULL,
  PRIMARY KEY (`rpId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `registrationpriorities`
--

INSERT INTO `registrationpriorities` (`rpId`, `rpPrio`, `rpName`, `rpDatasource`, `rpParameters`, `rpEnabled`) VALUES
(1, 1, '', 1, '', 0),
(2, 5, '', 1, '', 0),
(3, 6, '', 1, '', 0),
(4, 7, '', 1, '', 0),
(5, 8, '', 1, '', 0),
(6, 2, '', 1, '', 0),
(7, 3, '', 1, '', 0),
(8, 4, '', 1, '', 0),
(9, 9, 'Οι υπόλοιποι φοιτητές', 1, 'SELECT studAM, labID, Preference FROM studentPreferences;', 1);

-- --------------------------------------------------------

--
-- Table structure for table `statisticspreferencebreakdown`
--

CREATE TABLE IF NOT EXISTS `statisticspreferencebreakdown` (
  `Preference` tinyint(4) NOT NULL,
  `lotID` int(6) NOT NULL,
  `successfulRegistrations` int(11) NOT NULL,
  `failedRegistrations` int(11) NOT NULL,
  `totalRegistrations` int(11) NOT NULL,
  PRIMARY KEY (`Preference`,`lotID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `statisticspreferencebreakdown`
--


-- --------------------------------------------------------

--
-- Table structure for table `studentpreferences`
--

CREATE TABLE IF NOT EXISTS `studentpreferences` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `labID` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `Preference` int(2) NOT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `studentpreferences`
--


-- --------------------------------------------------------

--
-- Table structure for table `theoryschedule`
--

CREATE TABLE IF NOT EXISTS `theoryschedule` (
  `theoryScheduleEntryID` int(9) NOT NULL AUTO_INCREMENT,
  `courseID` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dayID` int(1) NOT NULL,
  `timeFrom` int(2) NOT NULL,
  `timeTo` int(2) NOT NULL,
  `roomID` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`theoryScheduleEntryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=53 ;

--
-- Dumping data for table `theoryschedule`
--

