-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2011 at 04:00 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `seep_internal`
--

-- --------------------------------------------------------

--
-- Table structure for table `concurrencylock`
--

CREATE TABLE IF NOT EXISTS `concurrencylock` (
  `lockTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lotID` int(6) NOT NULL,
  `last_lock_hostname` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `last_lock_ip` varchar(16) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `concurrencylock`
--


-- --------------------------------------------------------

--
-- Table structure for table `curstudentlab`
--

CREATE TABLE IF NOT EXISTS `curstudentlab` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `labID` varchar(19) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `curstudentlab`
--

INSERT INTO `curstudentlab` (`studAM`, `lotID`, `labID`) VALUES
('1006', 7, 'N15030E_6'),
('1138', -2, 'N17020AE_OLDSTUDENT'),
('1186', 7, 'N15030E_6'),
('1299', 7, 'N16010E_12'),
('1424', 7, 'N12040E_11'),
('1424', 7, 'N13010E_1'),
('1424', 7, 'N15020E_6'),
('1424', 7, 'N16010E_15'),
('1424', 7, 'N16040E_3'),
('1424', 7, 'N16060AE_3'),
('1424', 7, 'N16060BE_3'),
('1424', 7, 'N17010AE_1'),
('1424', 7, 'N17010BE_1'),
('1424', 7, 'N17030AE_2'),
('1424', 7, 'N17060AE_19'),
('1615', 7, 'N15030E_6'),
('1629', 7, 'N12010E_16'),
('1629', 7, 'N12040E_1'),
('1629', 7, 'N13010E_1'),
('1629', 7, 'N14010E_1'),
('1629', 7, 'N14040E_12'),
('1629', 7, 'N16010E_12'),
('1685', 7, 'N16010E_14'),
('1687', 7, 'N13010E_5'),
('1687', 7, 'N13040E_3'),
('1687', 7, 'N13050E_3'),
('1687', 7, 'N16010E_14'),
('1687', 7, 'N16020E_13'),
('1783', 7, 'N17060AE_18'),
('1818', 7, 'N12040E_1'),
('1818', 7, 'N14020E_5'),
('1818', 7, 'N14040E_7'),
('1818', 7, 'N15030E_9'),
('1922', 7, 'N12040E_2'),
('1922', 7, 'N13010E_5'),
('1922', 7, 'N15020E_2'),
('1922', 7, 'N15030E_9'),
('1922', 7, 'N15050E_2'),
('1922', 7, 'N15060E_7'),
('1922', 7, 'N16010E_15'),
('1922', 7, 'N16020E_13'),
('1922', 7, 'N16030E_4'),
('1944', 7, 'N13010E_1'),
('1944', 7, 'N14050E_3'),
('1944', 7, 'N15030E_6'),
('1944', 7, 'N15050E_2'),
('1944', 7, 'N15060E_8'),
('1944', 7, 'N17020AE_2'),
('1948', 7, 'N15030E_9'),
('1964', -2, 'N13010E_OLDSTUDENT'),
('1964', 7, 'N15010E_4'),
('1964', 7, 'N16010E_14'),
('1964', 7, 'N16020E_8'),
('1964', -2, 'N16060BE_OLDSTUDENT'),
('1964', 7, 'N17010BE_2'),
('1964', 7, 'N17060AE_18'),
('2012', 7, 'N16010E_12'),
('2012', 7, 'N16020E_9'),
('2012', 7, 'N16030E_1'),
('2012', 7, 'N16040E_1'),
('2012', 7, 'N16060AE_7'),
('2036', 7, 'N12040E_7'),
('2036', 7, 'N13010E_8'),
('2036', 7, 'N14010E_4'),
('2036', 7, 'N14040E_6'),
('2036', 7, 'N14050E_4'),
('2036', 7, 'N15050E_1'),
('2036', 7, 'N15060E_6'),
('2036', 7, 'N16010E_11'),
('2062', 7, 'N12040E_7'),
('2062', 7, 'N17010AE_4'),
('2062', 7, 'N17020BE_2'),
('2076', 7, 'N12040E_7'),
('2076', 7, 'N14010E_3'),
('2076', 7, 'N15030E_7'),
('2083', 7, 'N15030E_9'),
('2089', 7, 'N12040E_8'),
('2089', 7, 'N13010E_5'),
('2089', 7, 'N13050E_2'),
('2089', 7, 'N15030E_7'),
('2089', 7, 'N16010E_14'),
('2092', -2, 'N12010E_OLDSTUDENT'),
('2092', -2, 'N14020E_OLDSTUDENT'),
('2093', 7, 'N12010E_14'),
('2093', 7, 'N12040E_2'),
('2093', 7, 'N14020E_5'),
('2093', 7, 'N15030E_9'),
('2093', 7, 'N15060E_6'),
('2093', 7, 'N16040E_1'),
('2113', 7, 'N12010E_16'),
('2113', 7, 'N12040E_1'),
('2113', 7, 'N13010E_1'),
('2113', 7, 'N14010E_1'),
('2113', 7, 'N14020E_5'),
('2113', 7, 'N15060E_6'),
('2160', 7, 'N14010E_3'),
('2168', 7, 'N14010E_1'),
('2168', 7, 'N14020E_5'),
('2168', 7, 'N15010E_4'),
('2168', 7, 'N15020E_2'),
('2168', 7, 'N15030E_9'),
('2168', 7, 'N15050E_2'),
('2168', 7, 'N15060E_9'),
('2168', 7, 'N16010E_15'),
('2168', 7, 'N16020E_10'),
('2168', 7, 'N16030E_1'),
('2168', 7, 'N16040E_3'),
('2170', 7, 'N12040E_2'),
('2170', 7, 'N13010E_3'),
('2170', 7, 'N14030E_2'),
('2170', 7, 'N14050E_2'),
('2170', 7, 'N16010E_14'),
('2170', 7, 'N16020E_8'),
('2170', 7, 'N16060BE_3'),
('2189', 7, 'N13010E_5'),
('2189', 7, 'N15010E_4'),
('2189', 7, 'N15030E_6'),
('2189', 7, 'N16010E_11'),
('2189', 7, 'N16020E_8'),
('2189', 7, 'N16030E_4'),
('2210', 7, 'N14020E_1'),
('2210', 7, 'N14040E_12'),
('2210', 7, 'N16010E_11'),
('2210', 7, 'N16020E_10'),
('2210', 7, 'N16060AE_3'),
('2210', 7, 'N17030AE_3'),
('2243', 7, 'N15050E_1'),
('2243', 7, 'N16010E_15'),
('2243', 7, 'N16030E_1'),
('2243', 7, 'N16050BE_1'),
('2243', 7, 'N17020BE_2'),
('2243', 7, 'N17030AE_1'),
('2243', 7, 'N17040BE_1'),
('2243', 7, 'N17060AE_16'),
('2263', 7, 'N13030E_1'),
('2263', 7, 'N13040E_1'),
('2263', 7, 'N13050E_3'),
('2263', 7, 'N13060E_3'),
('2263', 7, 'N14030E_1'),
('2263', 7, 'N14040E_6'),
('2263', 7, 'N15020E_1'),
('2263', 7, 'N15060E_6'),
('2266', 7, 'N14040E_12'),
('2266', 7, 'N14050E_2'),
('2266', 7, 'N15020E_1'),
('2266', 7, 'N15060E_6'),
('2266', 7, 'N16010E_12'),
('2266', 7, 'N16060BE_3'),
('2268', 7, 'N13030E_1'),
('2268', 7, 'N13040E_1'),
('2268', 7, 'N13050E_12'),
('2268', 7, 'N14050E_1'),
('2268', 7, 'N15020E_1'),
('2268', 7, 'N15060E_6'),
('2268', 7, 'N16060BE_3'),
('2287', 7, 'N16010E_14'),
('2287', 7, 'N16060AE_3'),
('2287', 7, 'N17040AE_1'),
('2290', 7, 'N12010E_20'),
('2290', 7, 'N13050E_1'),
('2290', 7, 'N14030E_1'),
('2290', 7, 'N15060E_6'),
('2290', 7, 'N16020E_7'),
('2290', 7, 'N16040E_1'),
('2290', 7, 'N16060AE_7'),
('2296', 7, 'N13010E_5'),
('2296', 7, 'N14010E_4'),
('2296', 7, 'N16010E_12'),
('2296', 7, 'N16030E_4'),
('2296', 7, 'N16040E_1'),
('2296', 7, 'N16060BE_5'),
('2421', 7, 'N16010E_14'),
('2422', -2, 'N12010E_OLDSTUDENT'),
('2422', 7, 'N14020E_7'),
('2422', 7, 'N15010E_5'),
('2422', 7, 'N15050E_1'),
('2422', 7, 'N16010E_11'),
('2422', 7, 'N16020E_13'),
('2422', 7, 'N16050BE_1'),
('2423', 7, 'N15020E_4'),
('2423', 7, 'N16010E_12'),
('2423', 7, 'N16020E_7'),
('2423', 7, 'N16030E_3'),
('2423', 7, 'N16060AE_4'),
('2424', 7, 'N16060BE_5'),
('2425', 7, 'N16010E_14'),
('2427', 7, 'N16010E_11'),
('2427', 7, 'N16020E_7'),
('2427', 7, 'N16030E_1'),
('2427', 7, 'N16040E_2'),
('2427', 7, 'N16060AE_7'),
('2427', 7, 'N16060BE_3'),
('2428', 7, 'N16010E_11'),
('2428', 7, 'N16020E_13'),
('2428', 7, 'N16030E_1'),
('2428', 7, 'N16040E_1'),
('2428', 7, 'N16060AE_3'),
('2450', 7, 'N16010E_14'),
('2452', 7, 'N16010E_14'),
('2454', 7, 'N16010E_11'),
('2454', 7, 'N16020E_13'),
('2454', 7, 'N16030E_1'),
('2454', 7, 'N16060AE_3'),
('2454', 7, 'N17020AE_2'),
('2456', 7, 'N14010E_3'),
('2456', 7, 'N14040E_7'),
('2457', 7, 'N13010E_8'),
('2457', 7, 'N14020E_7'),
('2457', 7, 'N14040E_6'),
('2457', 7, 'N15010E_5'),
('2457', 7, 'N15020E_1'),
('2457', 7, 'N15050E_6'),
('2457', 7, 'N15060E_6'),
('2462', -2, 'N15010E_OLDSTUDENT'),
('2462', 7, 'N16010E_11'),
('2462', 7, 'N16020E_13'),
('2462', 7, 'N16030E_1'),
('2462', 7, 'N16060AE_3'),
('2465', 7, 'N16010E_12'),
('2465', 7, 'N16020E_7'),
('2465', 7, 'N16030E_1'),
('2465', 7, 'N16060AE_7'),
('2467', 7, 'N12010E_14'),
('2467', 7, 'N12050E_3'),
('2467', 7, 'N15060E_6'),
('2467', 7, 'N16020E_13'),
('2467', 7, 'N16040E_2'),
('2467', 7, 'N16060AE_3'),
('2469', 7, 'N12040E_11'),
('2469', 7, 'N14020E_7'),
('2469', 7, 'N16010E_11'),
('2469', 7, 'N16020E_7'),
('2469', 7, 'N16030E_2'),
('2469', 7, 'N16060AE_6'),
('3346', 7, 'N15060E_6'),
('3350', 7, 'N14010E_1'),
('3361', 7, 'N12010E_17'),
('3361', 7, 'N13030E_5'),
('3361', 7, 'N13040E_3'),
('3361', 7, 'N13050E_1'),
('3361', 7, 'N14040E_12'),
('3361', 7, 'N15020E_4'),
('3361', 7, 'N15030E_6'),
('3361', 7, 'N15060E_8'),
('3370', 7, 'N15030E_6'),
('3374', 7, 'N15030E_6'),
('3387', 7, 'N14010E_1'),
('3387', 7, 'N15020E_5'),
('3387', 7, 'N15050E_2'),
('3387', 7, 'N15060E_6'),
('391', -2, 'N14040E_OLDSTUDENT'),
('391', -2, 'N15010E_OLDSTUDENT'),
('391', -2, 'N16010E_OLDSTUDENT'),
('512', -2, 'N14020E_OLDSTUDENT'),
('512', 7, 'N15030E_7'),
('512', 7, 'N15050E_3'),
('512', -2, 'N16030E_OLDSTUDENT'),
('593', 7, 'N14020E_7'),
('593', 7, 'N16020E_10'),
('830', 7, 'N13010E_5'),
('830', 7, 'N13040E_3'),
('830', 7, 'N16010E_11'),
('830', 7, 'N16030E_4'),
('973', 7, 'N16010E_11');

-- --------------------------------------------------------

--
-- Table structure for table `failedstudentcourse`
--

CREATE TABLE IF NOT EXISTS `failedstudentcourse` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `courseID` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `failReason` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `failedstudentcourse`
--

INSERT INTO `failedstudentcourse` (`studAM`, `lotID`, `courseID`, `failReason`) VALUES
('1615', 7, 'N16010E', 'failedAllLabs');

-- --------------------------------------------------------

--
-- Table structure for table `failedstudentlab`
--

CREATE TABLE IF NOT EXISTS `failedstudentlab` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `lotID` int(6) NOT NULL,
  `labID` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `failReason` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `failedstudentlab`
--

INSERT INTO `failedstudentlab` (`studAM`, `lotID`, `labID`, `failReason`) VALUES
('2469', 7, 'N14020E_8', 'conflict'),
('2012', 7, 'N16010E_11', 'labFull'),
('2266', 7, 'N14040E_13', 'conflict'),
('1964', 7, 'N16010E_11', 'labFull'),
('1615', 7, 'N16010E_11', 'labFull'),
('1424', 7, 'N16010E_11', 'labFull'),
('1424', 7, 'N16040E_1', 'conflict'),
('1299', 7, 'N16010E_11', 'labFull'),
('2296', 7, 'N16060BE_3', 'conflict'),
('3361', 7, 'N15020E_5', 'conflict'),
('3361', 7, 'N15060E_6', 'conflict'),
('1944', 7, 'N15060E_6', 'labFull'),
('2170', 7, 'N14030E_3', 'conflict');

-- --------------------------------------------------------

--
-- Table structure for table `lotteries`
--

CREATE TABLE IF NOT EXISTS `lotteries` (
  `lotID` int(6) NOT NULL AUTO_INCREMENT,
  `lotDate` datetime NOT NULL,
  `lotExecuted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lotID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `lotteries`
--

INSERT INTO `lotteries` (`lotID`, `lotDate`, `lotExecuted`) VALUES
(7, '2011-03-23 21:00:00', 1),
(8, '2011-03-30 21:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `registrationpriorities`
--

CREATE TABLE IF NOT EXISTS `registrationpriorities` (
  `rpId` int(2) NOT NULL AUTO_INCREMENT,
  `rpPrio` int(2) NOT NULL,
  `rpName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rpDatasource` int(2) NOT NULL COMMENT '1 - SQL query στη βάση archonInternal',
  `rpParameters` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Οι παράμετροι που θα σταλούν στο datasource (πχ. το query)',
  `rpEnabled` int(1) NOT NULL,
  PRIMARY KEY (`rpId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `registrationpriorities`
--

INSERT INTO `registrationpriorities` (`rpId`, `rpPrio`, `rpName`, `rpDatasource`, `rpParameters`, `rpEnabled`) VALUES
(1, 1, '', 1, '', 0),
(2, 5, '', 1, '', 0),
(3, 6, '', 1, '', 0),
(4, 7, '', 1, '', 0),
(5, 8, '', 1, '', 0),
(6, 2, '', 1, '', 0),
(7, 3, '', 1, '', 0),
(8, 4, '', 1, '', 0),
(9, 9, 'Οι υπόλοιποι φοιτητές', 1, 'SELECT studAM, labID, Preference FROM studentPreferences;', 1);

-- --------------------------------------------------------

--
-- Table structure for table `statisticspreferencebreakdown`
--

CREATE TABLE IF NOT EXISTS `statisticspreferencebreakdown` (
  `Preference` tinyint(4) NOT NULL,
  `lotID` int(6) NOT NULL,
  `successfulRegistrations` int(11) NOT NULL,
  `failedRegistrations` int(11) NOT NULL,
  `totalRegistrations` int(11) NOT NULL,
  PRIMARY KEY (`Preference`,`lotID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `statisticspreferencebreakdown`
--

INSERT INTO `statisticspreferencebreakdown` (`Preference`, `lotID`, `successfulRegistrations`, `failedRegistrations`, `totalRegistrations`) VALUES
(1, 7, 240, 13, 253),
(2, 7, 12, 0, 12),
(3, 7, 0, 0, 0),
(4, 7, 0, 0, 0),
(5, 7, 0, 0, 0),
(6, 7, 0, 0, 0),
(7, 7, 0, 0, 0),
(8, 7, 0, 0, 0),
(9, 7, 0, 0, 0),
(10, 7, 0, 0, 0),
(11, 7, 0, 0, 0),
(12, 7, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentpreferences`
--

CREATE TABLE IF NOT EXISTS `studentpreferences` (
  `studAM` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `labID` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `Preference` int(2) NOT NULL,
  PRIMARY KEY (`studAM`,`labID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `studentpreferences`
--

INSERT INTO `studentpreferences` (`studAM`, `labID`, `Preference`) VALUES
('1138', 'N12010E_11', 1),
('1138', 'N12010E_12', 3),
('1138', 'N12010E_14', 2),
('1138', 'N16040E_1', 3),
('1138', 'N16040E_2', 4),
('1138', 'N16040E_3', 1),
('1138', 'N16040E_4', 2),
('2092', 'N12040E_1', 2),
('2092', 'N12040E_10', 3),
('2092', 'N12040E_11', 5),
('2092', 'N12040E_2', 1),
('2092', 'N12040E_3', 4),
('2092', 'N12040E_7', 6),
('2092', 'N12040E_8', 7),
('2092', 'N12040E_9', 8),
('2092', 'N14040E_12', 1),
('2092', 'N14040E_13', 5),
('2092', 'N14040E_5', 2),
('2092', 'N14040E_6', 3),
('2092', 'N14040E_7', 4),
('2092', 'N14050E_1', 1),
('2092', 'N14050E_2', 2),
('2092', 'N14050E_3', 5),
('2092', 'N14050E_4', 4),
('2092', 'N14050E_7', 3),
('2092', 'N15050E_1', 3),
('2092', 'N15050E_2', 1),
('2092', 'N15050E_3', 2),
('2092', 'N15050E_5', 5),
('2092', 'N15050E_6', 4),
('2092', 'N16020E_10', 2),
('2092', 'N16020E_13', 6),
('2092', 'N16020E_16', 5),
('2092', 'N16020E_7', 4),
('2092', 'N16020E_8', 1),
('2092', 'N16020E_9', 3),
('2092', 'N16060AE_3', 3),
('2092', 'N16060AE_4', 2),
('2092', 'N16060AE_6', 4),
('2092', 'N16060AE_7', 1),
('2092', 'N17030AE_1', 1),
('2092', 'N17030AE_2', 3),
('2092', 'N17030AE_3', 2),
('2287', 'N16030E_4', 1),
('2447', 'N16010E_11', 1),
('568', 'N12050E_1', 1),
('568', 'N12050E_2', 2),
('568', 'N12050E_3', 3),
('568', 'N14020E_1', 2),
('568', 'N14020E_5', 1),
('568', 'N14020E_7', 3),
('568', 'N14020E_8', 4),
('568', 'N14040E_12', 4),
('568', 'N14040E_13', 5),
('568', 'N14040E_5', 1),
('568', 'N14040E_6', 2),
('568', 'N14040E_7', 3),
('568', 'N15010E_4', 2),
('568', 'N15010E_5', 1),
('568', 'N15010E_9', 3),
('568', 'N15020E_1', 1),
('568', 'N15020E_2', 4),
('568', 'N15020E_4', 2),
('568', 'N15020E_5', 3),
('568', 'N15020E_6', 5),
('568', 'N15050E_1', 2),
('568', 'N15050E_2', 3),
('568', 'N15050E_3', 4),
('568', 'N15050E_5', 5),
('568', 'N15050E_6', 1),
('568', 'N15060E_10', 4),
('568', 'N15060E_6', 1),
('568', 'N15060E_7', 3),
('568', 'N15060E_8', 5),
('568', 'N15060E_9', 2),
('568', 'N16010E_11', 1),
('568', 'N16010E_12', 2),
('568', 'N16010E_14', 3),
('568', 'N16010E_15', 4),
('568', 'N16020E_10', 4),
('568', 'N16020E_13', 5),
('568', 'N16020E_16', 6),
('568', 'N16020E_7', 3),
('568', 'N16020E_8', 1),
('568', 'N16020E_9', 2),
('568', 'N16030E_1', 2),
('568', 'N16030E_2', 3),
('568', 'N16030E_3', 4),
('568', 'N16030E_4', 1),
('568', 'N16040E_1', 2),
('568', 'N16040E_2', 1),
('568', 'N16040E_3', 4),
('568', 'N16040E_4', 3),
('568', 'N16060BE_3', 1),
('568', 'N16060BE_5', 2),
('568', 'N16060BE_6', 3);

-- --------------------------------------------------------

--
-- Table structure for table `theoryschedule`
--

CREATE TABLE IF NOT EXISTS `theoryschedule` (
  `theoryScheduleEntryID` int(9) NOT NULL AUTO_INCREMENT,
  `courseID` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dayID` int(1) NOT NULL,
  `timeFrom` int(2) NOT NULL,
  `timeTo` int(2) NOT NULL,
  `roomID` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`theoryScheduleEntryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=53 ;

--
-- Dumping data for table `theoryschedule`
--

INSERT INTO `theoryschedule` (`theoryScheduleEntryID`, `courseID`, `dayID`, `timeFrom`, `timeTo`, `roomID`) VALUES
(1, 'N16010', 0, 12, 14, 0),
(2, 'N16020', 1, 10, 12, 0),
(3, 'N16030', 2, 12, 14, 0),
(4, 'N16040', 2, 10, 12, 0),
(5, 'N16050A', 2, 14, 16, 0),
(6, 'N16050B', 3, 10, 12, 0),
(7, 'N16060A', 4, 12, 14, 0),
(8, 'N16060B', 3, 8, 10, 0),
(9, 'N12010', 3, 10, 12, 0),
(10, 'N12020', 2, 14, 16, 0),
(11, 'N12030', 3, 14, 16, 0),
(12, 'N12040', 1, 10, 12, 0),
(13, 'N12050', 1, 14, 16, 0),
(14, 'N12040', 3, 12, 14, 0),
(15, 'N16020', 1, 8, 10, 0),
(16, 'N16040', 2, 8, 10, 0),
(17, 'N13050', 0, 8, 10, 0),
(18, 'N13050', 0, 10, 12, 0),
(19, 'N13010', 1, 8, 10, 0),
(20, 'N13010', 1, 10, 12, 0),
(21, 'N13060', 1, 12, 14, 0),
(22, 'N13030', 1, 16, 18, 0),
(23, 'N13020', 2, 8, 10, 0),
(24, 'N13040', 3, 10, 12, 0),
(25, 'N14010', 0, 10, 12, 0),
(26, 'N14010', 0, 12, 14, 0),
(27, 'N14040', 1, 8, 10, 0),
(28, 'N14040', 1, 10, 12, 0),
(29, 'N14020', 1, 12, 14, 0),
(30, 'N14050', 2, 10, 12, 0),
(31, 'N14030', 2, 12, 14, 0),
(32, 'N14060', 2, 14, 16, 0),
(33, 'N14060', 3, 12, 14, 0),
(34, 'N15040', 0, 10, 12, 0),
(35, 'N15040', 1, 12, 14, 0),
(36, 'N15020', 0, 14, 16, 0),
(37, 'N15050', 0, 16, 18, 0),
(38, 'N15030', 1, 14, 16, 0),
(39, 'N15010', 2, 12, 14, 0),
(40, 'N15060', 3, 12, 14, 0),
(41, 'N17050A', 0, 12, 14, 0),
(42, 'N17030B', 0, 16, 18, 0),
(43, 'N17020B', 1, 16, 18, 0),
(44, 'N17040A', 2, 8, 10, 0),
(45, 'N17040B', 2, 10, 12, 0),
(46, 'N17060A', 2, 12, 14, 0),
(47, 'N17050B', 2, 14, 16, 0),
(48, 'N17020A', 3, 8, 10, 0),
(49, 'N17060B', 3, 10, 12, 0),
(50, 'N17010A', 3, 12, 14, 0),
(51, 'N17030A', 4, 10, 12, 0),
(52, 'N17010B', 4, 12, 14, 0);
